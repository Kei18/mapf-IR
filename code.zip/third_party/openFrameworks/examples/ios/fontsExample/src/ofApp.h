#pragma once

#include "ofxiOS.h"

class ofApp : public ofxiOSApp{
	
    public:
        void setup();
        void update();
        void draw();
        void exit();
    
        void touchDown(ofTouchEventArgs & touch);
        void touchMoved(ofTouchEventArgs & touch);
        void touchUp(ofTouchEventArgs & touch);
        void touchDoubleTap(ofTouchEventArgs & touch);
        void touchCancelled(ofTouchEventArgs & touch);
	
        void lostFocus();
        void gotFocus();
        void gotMemoryWarning();
        void deviceOrientationChanged(int newOrientation);
	
        bool bFirst;
        string typeStr;
	
        ofTrueTypeFont franklinBook14;
        ofTrueTypeFont verdana14;
        ofTrueTypeFont verdana30;
	
        ofTrueTypeFont franklinBook14A;
        ofTrueTypeFont verdana14A;
	
        ofPoint touchPt;
        ofPoint drag;
        bool bDragging;
	
};


