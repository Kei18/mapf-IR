//
//  CustomAppViewController.h
//  Created by lukasz karluk on 8/02/12.
//

#import "ofxiOSViewController.h"

@interface TriangleAppViewController : ofxiOSViewController

@end
