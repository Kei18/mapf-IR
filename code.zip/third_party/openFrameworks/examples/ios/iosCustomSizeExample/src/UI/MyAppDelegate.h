//
//  MyAppDelegate.h
//  Created by lukasz karluk on 12/12/11.
//

#import "ofxiOSAppDelegate.h"

@interface MyAppDelegate : ofxiOSAppDelegate {
    //
}

@property (nonatomic, retain) UINavigationController* navigationController;

@end
