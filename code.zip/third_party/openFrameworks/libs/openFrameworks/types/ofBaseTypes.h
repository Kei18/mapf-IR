#pragma once

#include "ofGLBaseTypes.h"
#include "ofGraphicsBaseTypes.h"
#include "ofSoundBaseTypes.h"
#include "ofVideoBaseTypes.h"
