#pragma once

static const std::string DEFAULT_OUTPUT_FILE = "./result.txt";
static const int DEFAULT_SEED = 0;
static const int DEFAULT_MAX_TIMESTEP = 5000;
static const int DEFAULT_MAX_COMP_TIME = 60000;
