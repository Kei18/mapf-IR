#!/bin/bash
`dirname $0`/visualizer/bin/visualizer.app/Contents/MacOS/visualizer $1
